package com.cometchat.pro.uikit.ui_resources.utils.keyboard_utils;

public interface KeyboardVisibilityListener {

    void onKeyboardVisibilityChanged(boolean keyboardVisible);

}