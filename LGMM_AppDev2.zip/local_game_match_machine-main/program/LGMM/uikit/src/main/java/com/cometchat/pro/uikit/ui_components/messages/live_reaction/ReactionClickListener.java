package com.cometchat.pro.uikit.ui_components.messages.live_reaction;

import android.view.View;

public abstract class ReactionClickListener {
    public void onClick(View var1){}
    public void onCancel(View var1){}
}
