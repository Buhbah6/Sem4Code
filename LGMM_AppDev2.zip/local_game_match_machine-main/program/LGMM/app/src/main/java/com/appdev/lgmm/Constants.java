package com.appdev.lgmm;

public interface Constants {
    String APP_ID = "xxx-xxx-xxx";
    String AUTH_KEY = "xxx-xxx-xxx";
    String REGION = "xxx-xxx-xxx";
    String API_KEY = "xxx-xxx-xxx";
}
