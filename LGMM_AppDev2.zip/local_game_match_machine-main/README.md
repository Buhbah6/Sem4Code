# Local Game Match Machine

Winter 2022. Repository for Application Development (Mobile) term project.

## Description

Our project is a gaming chat for local multiplayer games. <br>
Its goal is to help you find people near you who are playing the same game.

## Getting Started

## Contributors

Anthony Nadeau (2058983) <br>
Shahe Bannis (2051001) <br>
Giuliana Bouzon (1940108)

## License

This project is licensed under the GNU/General Public License version 3.0