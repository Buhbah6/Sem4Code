package networks;

import java.io.*;
import java.util.*;

/**
 * The driver class for Question 2 of Assignment 2
 * Course: Networks
 * @author Anthony Nadeau
 */
public class Networks {

    public static void main(String[] args) throws FileNotFoundException {
        // Relative path - Should work on any device with the project
        String file = "src\\resources\\nodes.txt";
        
        // Scanner objects to pass to the respective methods
        Scanner read = new Scanner(new File(file));
        Scanner input = new Scanner(System.in);
        
        // Retrieving the fileContents and the starting and ending nodes
        ArrayList<String> fileContents = readFromFile(read);
        ArrayList<String> userInputtedNodes = userInput(input, fileContents);
        
        // Using the buildGraph method to store all the nodes from the file in a graph
        Graph graph = buildGraph(fileContents, new Graph());
        
        // Creating Dijkstra object to take the graph and the user inputted nodes and calculate the shortest path
        Dijkstra dijkstra = new Dijkstra();
        
        // calling the algorithm and storing the result
        int shortestDistance = dijkstra.DijkstrasAlgorithm(graph, 
                graph.getNodeByName(userInputtedNodes.get(0)), graph.getNodeByName(userInputtedNodes.get(1)));
        
        // Printing the output
        System.out.println(String.format("The shortest path from Node %s to Node %s has a distance of %d",
                userInputtedNodes.get(0), userInputtedNodes.get(1), shortestDistance));
    }
    
    /**
     * Transforms the ArrayList of strings into a set of Nodes inside of a graph
     * and establishes the edges between each of them them
     * @param fileContents an ArrayList of Strings pulled from a text file
     * @param graph the graph that will contain the nodes
     * @return the populated graph
     */
    public static Graph buildGraph(ArrayList<String> fileContents, Graph graph) {
        
        // For Each that creates all the nodes declared in the file
        for (String str : fileContents) {
            if (graph.getNodeByName(str.charAt(0) + "") == null) {
                graph.add(new Node(str.charAt(0) + ""));
            }
            if (graph.getNodeByName(str.charAt(1) + "") == null) {
                graph.add(new Node(str.charAt(1) + ""));
            }
        }
        
        // For Each that assigns each neighbour of a node to the node and the edge linking them
        for (String str : fileContents) {
            Node node = graph.getNodeByName(str.charAt(0) + ""); // gets the first node of a line
            // adds the second node of a line as a neighbour to the first node, and sets the cost
            node.addNeighbour(graph.getNodeByName(str.charAt(1) + ""), Integer.parseInt(str.charAt(2) + ""));
            graph.replaceNode(node); // replaces the original node with the newly updated one
            // repeats the above process but swapping the first and second nodes of the line
            node = graph.getNodeByName(str.charAt(1) + "");
            node.addNeighbour(graph.getNodeByName(str.charAt(0) + ""), Integer.parseInt(str.charAt(2) + ""));
            graph.replaceNode(node);
        }
        return graph; // Return the populated graph with all completed Nodes
    }
    
    /**
     * Method that retrieves each line from a file and stores it as a string in an ArrayList
     * @param read a Scanner with a file passed to it containing the relative path to the file
     * @return an ArrayList containing each line of the passed file as a String
     */
    public static ArrayList<String> readFromFile(Scanner read) {
        ArrayList<String> fileContents = new ArrayList<>();
        while(read.hasNextLine()){
            fileContents.add(read.nextLine());                     
        }
        return fileContents;
    }
    
    /**
     * Method that prompts the user to enter 2 valid node names
     * @param input a Scanner that takes input through the console
     * @param nodes an ArrayList of node names 
     * @return an ArrayList containing the starting and ending nodes for the shortest path algorithm
     */
    public static ArrayList<String> userInput(Scanner input, ArrayList<String> nodes) {
        boolean invalid = true;
        ArrayList<String> userNodes = new ArrayList<>();
        while (invalid) { // Ensures that the nodes entered by the user are valid nodes pulled from the file
            System.out.println("Please enter a node as represented by a character (e.g. \'A\')");
            char node = Character.toUpperCase(input.next().charAt(0));
            for (String distance : nodes) {
                if (distance.contains(node + "")) {
                    userNodes.add(node + "");
                    if (userNodes.size() == 2)
                        invalid = false;
                    break;
                }
            }
        }
        return userNodes;
    }
}
  
/**
 * Class that contains the methods to complete Dijkstra's Algorithm
 * @author Anthony Nadeau
 */
class Dijkstra {
    // Map that stores a node, and the priority of the node, where the smaller numbers take priority
    private Map<Node, Integer> priorityMap; 

    /**
     * Default Constructor
     */
    public Dijkstra() {
        priorityMap = new HashMap<>();
    }

    /**
     * Primary Algorithm, calculates the shortest distance between the start node
     * and the end node inside a graph
     * @param graph the graph containing all the nodes
     * @param start the source node AKA the start of the algorithm
     * @param end the destination node AKA the end of the algorithm
     * @return the shortest distance between the start and end nodes
     */
    public int DijkstrasAlgorithm(Graph graph, Node start, Node end) {
        Map<Node, Integer> totalCosts = new HashMap<>(); // Stores each Node with the smallest cost to the source node
        Set<Node> visited = new HashSet<>(); // Creates a set to view previously visited nodes
        
        // Put the source node at the start of the of the totalCosts with a cost of 0
        totalCosts.put(start, 0);
        // Put the source node at the start of the priority map with the maximum priority
        priorityMap.put(start, 0);

        // for each node contained in the graph, add the node to totalCosts and the priority map (Except the source)
        for (Node node : graph.getNodeCollection()) {
            if (!node.equals(start)) {
                totalCosts.put(node, Integer.MAX_VALUE);
                priorityMap.put(node, Integer.MAX_VALUE);
            }
        }

        // Each iteration removes a node from the priority map and adds it to the visited set
        while (!priorityMap.isEmpty()) {
            // Removes the node with the smallest priority value and stores it
            Node newSmallest = removeSmallestInMap();
            
            // for each neighbour of the smallest node
            for (Node neighbour : newSmallest.getNeighbourNodes().keySet()) {
                // if the neighbour has not been visited
                if (!visited.contains(neighbour)) {
                    
                    // altPath is the current cost of the smallest node + the distance from the node to this neighbour
                    int altPath = totalCosts.get(newSmallest) + newSmallest.getDistanceFromNeighbour(neighbour);
                    // if the altPath is smaller than the currently set cost to this neighbour
                    if (altPath < totalCosts.get(neighbour)) {
                        totalCosts.put(neighbour, altPath); // set the cost to the new smaller cost
                        priorityMap.put(neighbour, altPath); // update the priority (to be lower in value, but higher in priority)
                    }
                }
            }
            // Add the newSmallest node to the visited list, so it will not be revisited
            visited.add(newSmallest);
        }
        // return the total cost of the destination node from the source node
        return totalCosts.get(end);
    }

    /**
     * Retrieves the node with the smallest priority in the priority map
     * @return the node with the smallest priority
     */
    public Node getSmallestInMap() {
        Node smallestPriorityNode = new Node("");
        int priority = Integer.MAX_VALUE; // Sets priority to highest value
        for (Node node : priorityMap.keySet()) { // for each node in the map
            if (priorityMap.get(node) < priority) { // check if the node's priority is smaller than the current priority
                smallestPriorityNode = node; // set the smallest priority node to the current node
                priority = priorityMap.get(node); // set priority to the current node's priority
            }
        }
        return smallestPriorityNode; // return the smallest priority node
    }

    /**
     * Gets the node with the smallest priority in the priority map and removes it
     * @return the node with the smallest priority
     */
    public Node removeSmallestInMap() {
        Node smallestNode = getSmallestInMap();
        priorityMap.remove(smallestNode);
        return smallestNode;
    }

}

/**
 * Graph class, contains all the nodes
 * @author Anthony Nadeau
 */
class Graph {
    private Set<Node> nodeCollection; // Set of all Nodes to give to the algorithm later on

    /**
     * Default Constructor
     */
    public Graph() {
        nodeCollection = new HashSet<>();
    }

    /**
     * Constructor with all instance variables
     * @param nodeCollection Set being stored in instance variable
     */
    public Graph(Set<Node> nodeCollection) {
        this.nodeCollection = nodeCollection;
    }

    /**
     * Adds a node to the Node set
     * @param node node being added to the set
     */
    public void add(Node node) {
        nodeCollection.add(node);
    }

    /**
     * Retrieves a node from the set using the name of the node
     * @param name the name of the node being searched for
     * @return the node assigned to the given name
     */
    public Node getNodeByName(String name) {
        for (Node node : nodeCollection) {
            if (node.getLetterName().equals(name))
                return node;
        }
        return null;
    }
    
    /**
     * Replaces the node in the set with the updated version of itself
     * @param node the node to replace the old version with
     */
    public void replaceNode(Node node) {
        nodeCollection.remove(getNodeByName(node.getLetterName()));
        add(node);
    }
    
    // GETTERS AND SETTERS //

    public Set<Node> getNodeCollection() {
        return nodeCollection;
    }

    public void setNodeCollection(Set<Node> nodeCollection) {
        this.nodeCollection = nodeCollection;
    }     
}

/**
 * Node class, represents each vertex in the graph
 * @author Anthony Nadeau
 */
class Node {
    private String letterName; // Name of the Node
    private Map<Node, Integer> neighbourNodes; // Neighbours and distance to each

    /**
     * Constructor that takes a name
     * @param letterName the name being passed to the node
     */
    public Node(String letterName) {
        this.letterName = letterName;
        neighbourNodes = new HashMap<Node, Integer>();
    }

    /**
     * Adds a node to the neighbourNodes map
     * @param node the node being added as a neighbour
     * @param distanceToNode the distance to the new neighbour node
     */
    public void addNeighbour(Node node, int distanceToNode) {
        neighbourNodes.put(node, distanceToNode);
    }

    /**
     * Gets the distance to the given node
     * @param node the neighbour of which the distance to is being retrieved
     * @return the distance to the given neighbour node
     */
    public int getDistanceFromNeighbour(Node node) {
        return neighbourNodes.get(node);
    }

    /**
     * Retrieves a neighbourNode from the map using the name
     * @param name the name of the node being searched for
     * @return the node with the given name
     */
    public Node getNeighbourByName(String name) {
        for (Node node : neighbourNodes.keySet()) {
            if (node.getLetterName().equals(name))
                return node;
        }
        return null;
    }
    
    /**
     * Overridden toString
     * @return the Node as a string
     */
    @Override
    public String toString() {
        return "Node{" + "letterName=" + letterName + ", neighbourNodes=" + neighbourNodes + '}';
    }
    
    // GETTERS AND SETTERS
    
    public String getLetterName() {
        return letterName;
    }

    public void setLetterName(String letterName) {
        this.letterName = letterName;
    }

    public Map<Node, Integer> getNeighbourNodes() {
        return neighbourNodes;
    }

    public void setNeighbourNodes(Map<Node, Integer> neighbourNodes) {
        this.neighbourNodes = neighbourNodes;
    }
}  
