# ecom-assignment1
Winter 2022. Repository for Assignment 1 in eCommerce couse. 
