<link rel="stylesheet" type="text/css" href="/public/css/layout.css">

<aside>
    <ul>
        <li><a href = "/Main/index">Landing Page</a></li>
        <li><a href = "/Main/about_us">About Us</a></li>
        <li><a href = "/Contact/index">Contact Us</a></li>
        <li><a href = "/Contact/read">View All Messages</a></li>
    </ul>
</aside>