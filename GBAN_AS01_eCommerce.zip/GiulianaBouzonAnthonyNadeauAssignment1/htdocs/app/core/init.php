<?php
    //TODO: more initialization goes in here
    require_once('app\\core\\autoload.php');