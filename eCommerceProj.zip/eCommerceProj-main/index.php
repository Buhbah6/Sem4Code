<?php
    require_once('app\\core\\init.php'); //relative path
    new \app\core\App();