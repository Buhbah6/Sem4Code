# eCommerceProj
Repo for eCommerce Project
# Project Name:
## FurnitureLand
The furniture market is evolving as demographics shift and consumers’ buying habits change. No furniture seller can afford to have a poor marketing strategy.Hence, with our application, users will be able to buy and sell furniture in a no time.

## Idea
Marketplace for furniture -> Amazon style but exclusively for furniture and home appliances
We can have multiple furniture brands choose to sell their products on the marketplace

# End Goal:
In COVID times, many people have been moving out of urban locations to live in more rural areas. With that comes the opportunity to have larger homes
at a better price, allowing for more space for different furniture pieces. That's why we've decided that we want to create a hub where people can find 
furniture of any brand, new or used, to ease the experience of purchasing furniture and make it an overall more pleasant shopping adventure.


# License
[MIT]
