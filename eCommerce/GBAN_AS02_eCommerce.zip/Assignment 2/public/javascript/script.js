$(document).ready(function() {
    var editor = new Editor();
    editor.render();
    editor.codemirror.getValue();
});