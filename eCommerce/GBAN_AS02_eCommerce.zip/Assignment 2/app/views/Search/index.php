<html>
	<head>
		<title>Search</title>
	</head>
	<body>
		<form method="post" action = "" style = "position:absolute;top:10px;right:100px;">
			<input type="text" name="search">
			<select name = "search_type">
				<option value = "title">Search By Title</option>
				<option value = "content">Search By Content</option>
			</select>
			<button type="submit" name="action">Search</button>
		</form>
	</body>
</html>