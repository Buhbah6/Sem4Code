<html>
	<head>
		<title>Search</title>
	</head>
	<body>
		<form method="post" action = "">
			<input type="text" name="search">
			<button type="submit" name="action">Search</button>
		</form>
	</body>
</html>