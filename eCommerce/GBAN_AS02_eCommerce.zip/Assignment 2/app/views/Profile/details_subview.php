	<h1>Profile details</h1>
	<form method='post' action=''>
		<label class='form-label'>First name:<input type='text' name='first_name' class='form-control' value='<?= $data->first_name?>' /></label><br>
		<label class='form-label'>Middle name:<input type='text' name='middle-name' class='form-control' value='<?= $data->middle_name?>' /></label><br>
		<label class='form-label'>Last name:<input type='text' name='last_name' class='form-control' value='<?= $data->last_name?>' /></label><br>
	</form>