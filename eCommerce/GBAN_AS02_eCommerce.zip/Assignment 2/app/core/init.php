<?php
	session_start();
	require_once('app/core/autoload.php');